﻿using System;

namespace AssemblyCSharp
{
	public class JoustMode
	{
		
	}
}

