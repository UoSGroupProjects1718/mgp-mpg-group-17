﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerOne {
	public static float health = 100;
	public static bool winner = false;
	public static float spellCooldown = 0;
	public static float parryCooldown = 0;
	public static float attackCooldown = 0;
}
